configuration ConfigureSiosVM0
{
    param
    (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [String]$DomainNetbiosName=(Get-NetBIOSName -DomainName $DomainName),

		[Parameter(Mandatory)]
        [String]$LicenseKeyFtpURL,
				
		[Parameter(Mandatory)]
        [String]$ClusterName,

        [Parameter(Mandatory)]
        [String]$SharePath,

        [Parameter(Mandatory)]
        [String[]]$Nodes,

        [Int]$RetryCount=20,
				
        [Int]$RetryIntervalSec=30		 
    )

	$node0 = "sios-0." + $DomainName	
	$node1 = "sios-1." + $DomainName

    Import-DscResource -ModuleName cDisk, xActiveDirectory, xComputerManagement, xDataKeeper, xDisk, xFailOverCluster, xNetworking
    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainNetbiosName}\$($Admincreds.UserName)", $Admincreds.Password)
    
    Enable-CredSSPNTLM -DomainName $DomainName

    Node localhost
    {
        xWaitforDisk Disk2
        {
             DiskNumber = 2
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
        }

        cDiskNoRestart DataDisk
        {
            DiskNumber = 2
            DriveLetter = "F"
        }

	WindowsFeature FS
	{
		Name = "File-Services"
		Ensure = "Present"
	}

        WindowsFeature FC
        {
            Name = "Failover-Clustering"
            Ensure = "Present"
			DependsOn = "[WindowsFeature]FS"
        }

		WindowsFeature FCMGMT
		{
			Name = "RSAT-Clustering-Mgmt"
			Ensure = "Present"
		}

        WindowsFeature FCPS
        {
            Name = "RSAT-Clustering-PowerShell"
            Ensure = "Present"
        }

        WindowsFeature ADPS
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        }
				
        xWaitForADDomain DscForestWait 
        { 
            DomainName = $DomainName 
            DomainUserCredential= $DomainCreds
            RetryCount = $RetryCount 
            RetryIntervalSec = $RetryIntervalSec 
						DependsOn = "[WindowsFeature]ADPS"
        }
				
        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $DomainCreds
			DependsOn = "[xWaitForADDomain]DscForestWait"
        }

		InstallLicense GetDKCELic
		{
			LicenseKeyFtpURL = $LicenseKeyFtpURL 
            RetryIntervalSec = $RetryIntervalSec
			RetryCount = $RetryCount 
			DependsOn = "[xComputer]DomainJoin"
		}
		
		sService StartExtMirr
		{
			Name = "extmirrsvc"
			StartupType = "Automatic"
			State = "Running"
			DependsOn = "[InstallLicense]GetDKCELic"
		}

		CreateJob NewJob
		{
			JobName 	= "Volume F Replication"
			JobDesc 	= "Protection for File Server Role"
			SourceName 	= $node0
			SourceIP 	= "10.0.0.5"
			SourceVol 	= "F"
			TargetName 	= $node1
			TargetIP 	= "10.0.0.6"
			TargetVol 	= "F"
			SyncType	= "A"
			RetryIntervalSec = 20 
			RetryCount		 = 30 
			DependsOn = "[sService]StartExtMirr"
		}

		CreateMirror NewMirror
		{
			SourceIP 	= "10.0.0.5"
			Volume	 	= "F"
			TargetIP 	= "10.0.0.6"
			SyncType	= "S"
			RetryIntervalSec = 20 
			RetryCount		 = 30
			DependsOn = "[CreateJob]NewJob"
		}

		xCluster FailoverCluster
        {
            Name = $ClusterName
            DomainAdministratorCredential = $DomainCreds
			Nodes = $Nodes
			DependsOn="[CreateMirror]NewMirror"
        }

        xWaitForFileShareWitness WaitForFSW
        {
            SharePath = $SharePath
            DomainAdministratorCredential = $DomainCreds
        }

        xClusterQuorum FailoverClusterQuorum
        {
            Name = $ClusterName
            SharePath = $SharePath
            DomainAdministratorCredential = $DomainCreds
        }
		
		Script RegClusVol
		{
			SetScript = {
				for ($count = 0; $count -lt $RetryCount; $count++)
				{
					$results = & "$env:extmirrbase\emcmd" . REGISTERCLUSTERVOLUME F
					
					if($results.Contains("Status = 0")) {
						break			
					} else {
						Start-Sleep -Seconds $RetryIntervalSec
					}
				}				
				
				mkdir C:\TempDB
				#Add-ClusterFileServerRole -Name "DKFileServer" -Storage "DataKeeper Volume F" -Cluster $ClusterName -StaticAddress "10.0.0.200" 
			}
			TestScript = { $false }
			GetScript = {@{}}
			Credential = $AdminCreds
			DependsOn = "[xCluster]FailoverCluster"
		}
		
        LocalConfigurationManager 
        {
            RebootNodeIfNeeded = $true
        }
    }
}

function Get-NetBIOSName
{ 
    [OutputType([string])]
    param(
        [string]$DomainName
    )

    if ($DomainName.Contains('.')) {
        $length=$DomainName.IndexOf('.')
        if ( $length -ge 16) {
            $length=15
        }
        return $DomainName.Substring(0,$length)
    }
    else {
        if ($DomainName.Length -gt 15) {
            return $DomainName.Substring(0,15)
        }
        else {
            return $DomainName
        }
    }
}

function Enable-CredSSPNTLM
{ 
    param(
        [Parameter(Mandatory=$true)]
        [string]$DomainName
    )
    
    # This is needed for the case where NTLM authentication is used

    Write-Verbose 'STARTED:Setting up CredSSP for NTLM'
   
    Enable-WSManCredSSP -Role client -DelegateComputer localhost, *.$DomainName -Force -ErrorAction SilentlyContinue
    Enable-WSManCredSSP -Role server -Force -ErrorAction SilentlyContinue

    if(-not (Test-Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -ErrorAction SilentlyContinue))
    {
        New-Item -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows -Name '\CredentialsDelegation' -ErrorAction SilentlyContinue
    }

    if( -not (Get-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -Name 'AllowFreshCredentialsWhenNTLMOnly' -ErrorAction SilentlyContinue))
    {
        New-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -Name 'AllowFreshCredentialsWhenNTLMOnly' -value '1' -PropertyType dword -ErrorAction SilentlyContinue
    }

    if (-not (Get-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -Name 'ConcatenateDefaults_AllowFreshNTLMOnly' -ErrorAction SilentlyContinue))
    {
        New-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -Name 'ConcatenateDefaults_AllowFreshNTLMOnly' -value '1' -PropertyType dword -ErrorAction SilentlyContinue
    }

    if(-not (Test-Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -ErrorAction SilentlyContinue))
    {
        New-Item -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -Name 'AllowFreshCredentialsWhenNTLMOnly' -ErrorAction SilentlyContinue
    }

    if (-not (Get-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name '1' -ErrorAction SilentlyContinue))
    {
        New-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name '1' -value "wsman/$env:COMPUTERNAME" -PropertyType string -ErrorAction SilentlyContinue
    }

    if (-not (Get-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name '2' -ErrorAction SilentlyContinue))
    {
        New-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name '2' -value "wsman/localhost" -PropertyType string -ErrorAction SilentlyContinue
    }

    if (-not (Get-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name '3' -ErrorAction SilentlyContinue))
    {
        New-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name '3' -value "wsman/*.$DomainName" -PropertyType string -ErrorAction SilentlyContinue
    }

    Write-Verbose "DONE:Setting up CredSSP for NTLM"
}