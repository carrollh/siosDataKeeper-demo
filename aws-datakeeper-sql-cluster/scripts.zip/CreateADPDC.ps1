﻿param 
( 
	[Parameter(Mandatory)]
	[String]$DomainName,

	[Parameter(Mandatory)]
	[String]$AdminUsername,
	
	[Parameter(Mandatory)]
	[String]$AdminPassword,

	[Parameter(Mandatory)]
	[String]$SharePath,

	[Int]$RetryCount=2,
	[Int]$RetryIntervalSec=60
) 

function Add-TopLevelDomain
{ 
    [OutputType([string])]
    param(
        [string]$DomainName
    )

    if ($DomainName.Contains('.')) {
        return $DomainName
    }
    else {
        return ($DomainName + ".local")
    }
}

$ErrorActionPreference = "Stop"

Import-Module $psscriptroot\IPHelper.psm1

Configuration LCMConfig {
	LocalConfigurationManager {
		RebootNodeIfNeeded = $true
		CertificateID = (Get-ChildItem Cert:\LocalMachine\My)[0].Thumbprint
	}
}

LCMConfig
Set-DscLocalConfigurationManager -Path .\LCMConfig

$ConfigurationData = @{
	AllNodes = @(
		@{
			NodeName = 'ad-pdc'
			CertificateFile = 'C:\dsc.cer'
		}
	)
}

$Pass = ConvertTo-SecureString $AdminPassword -AsPlainText -Force
$domainFQDN = Add-TopLevelDomain -DomainName $DomainName
$DomainCreds = New-Object System.Management.Automation.PSCredential ("$domainFQDN\$AdminUsername", $Pass)
	
configuration CreateADPDC 
{ 
	Import-DscResource -ModuleName cDisk, xActiveDirectory, xDisk, xNetworking, xSMBShare, PSDesiredStateConfiguration
	
	$Interface=Get-NetAdapter|Where Name -Like "Ethernet*"|Select-Object -First 1
	$InterfaceAlias=$($Interface.Name)	

	Node ad-pdc
	{	
		WindowsFeature DNS 
		{ 
			Ensure = "Present" 
			Name = "DNS"		
		}

		Script script1
		{
			SetScript =  { 
				Set-DnsServerDiagnostics -All $true
				Write-Verbose -Verbose "Enabling DNS client diagnostics"
			}
			GetScript =  { @{} }
			TestScript = { $false}
			DependsOn = "[WindowsFeature]DNS"
		}
		
		xIPAddress PrivateIPAddress {
			IPAddress = '10.0.0.4'
			InterfaceAlias = 'Ethernet'
			PrefixLength = 24
			AddressFamily = 'IPv4'
		}
		
		xDnsServerAddress DnsServerAddress 
		{ 
			Address        = '127.0.0.1' 
			InterfaceAlias = 'Ethernet'
			AddressFamily  = 'IPv4'
			DependsOn = "[xIPAddress]PrivateIPAddress"
		}
		
		WindowsFeature DnsTools
		{
			Ensure = "Present"
			Name = "RSAT-DNS-Server"
			DependsOn = "[xDnsServerAddress]DnsServerAddress"
		}
		
		WindowsFeature ADDSInstall 
		{ 
			Ensure = "Present" 
			Name = "AD-Domain-Services"
			DependsOn = "[WindowsFeature]DNS"
		}  
		
		WindowsFeature ADDSToolsInstall {
			Ensure = 'Present'
			Name = 'RSAT-ADDS-Tools'
			DependsOn = "[WindowsFeature]ADDSInstall"
		}

		xADDomain FirstDS 
		{
			DomainName = $domainFQDN
			DomainAdministratorCredential = $DomainCreds
			SafemodeAdministratorPassword = $DomainCreds
			DatabasePath = "C:\NTDS"
			LogPath = "C:\NTDS"
			SysvolPath = "C:\SYSVOL"
			DependsOn = "[WindowsFeature]ADDSToolsInstall"
		} 
		
		Service RestartNetLogon
		{
			Name = "NetLogon"
			StartupType = "Automatic"
			State = "Running"
			DependsOn = "[xADDomain]FirstDS"
		}

		File FSWFolder
		{
			DestinationPath = "C:\$($SharePath.ToUpperInvariant())"
			Type = "Directory"
			Ensure = "Present"
			DependsOn = "[xADDomain]FirstDS"
		}

		xSmbShare FSWShare
		{
			Name = $SharePath.ToUpperInvariant()
			Path = "C:\$($SharePath.ToUpperInvariant())"
			FullAccess = "BUILTIN\Administrators"
			Ensure = "Present"
			DependsOn = "[File]FSWFolder"
		}

		LocalConfigurationManager 
		{
			ConfigurationMode = 'ApplyOnly'
			RebootNodeIfNeeded = $true
		}
	}
}

CreateADPDC -ConfigurationData $ConfigurationData
Start-DscConfiguration -Path .\CreateADPDC -Wait -Verbose -ErrorVariable ev
