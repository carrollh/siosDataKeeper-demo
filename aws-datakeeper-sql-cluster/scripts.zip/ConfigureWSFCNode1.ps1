param
(
	[Parameter(Mandatory)]
	[String]$DomainName,

	[Parameter(Mandatory)]
	[String]$AdminUsername,
	
	[Parameter(Mandatory)]
	[String]$AdminPassword,
	
	[Parameter(Mandatory)]
	[String]$LicenseKeyFtpURL,
			
	[Parameter(Mandatory)]
	[String]$ClusterName,

	[Parameter(Mandatory)]
	[String[]]$Nodes,

	[Int]$RetryCount=10,
			
	[Int]$RetryIntervalSec=180	
)

function Get-NetBIOSName
{ 
    [OutputType([string])]
    param(
        [string]$DomainName
    )

    if ($DomainName.Contains('.')) {
        $length=$DomainName.IndexOf('.')
        if ( $length -ge 16) {
            $length=15
        }
        return $DomainName.Substring(0,$length)
    }
    else {
        if ($DomainName.Length -gt 15) {
            return $DomainName.Substring(0,15)
        }
        else {
            return $DomainName
        }
    }
}

function Add-TopLevelDomain
{ 
    [OutputType([string])]
    param(
        [string]$DomainName
    )

    if ($DomainName.Contains('.')) {
        return $DomainName
    }
    else {
        return ($DomainName + ".local")
    }
}

	$ErrorActionPreference = "Stop"

	Import-Module $psscriptroot\IPHelper.psm1

	Configuration LCMConfig {
		LocalConfigurationManager {
			RebootNodeIfNeeded = $true
			CertificateID = (Get-ChildItem Cert:\LocalMachine\My)[0].Thumbprint
		}
	}

	LCMConfig
	Set-DscLocalConfigurationManager -Path .\LCMConfig

	$ConfigurationData = @{
		AllNodes = @(
			@{
				NodeName = 'localhost'
				CertificateFile = 'C:\dsc.cer'
			}
		)
	}

	$Pass = ConvertTo-SecureString $AdminPassword -AsPlainText -Force
	$domainFQDN = Add-TopLevelDomain -DomainName $DomainName
	$domainNETBIOSName = Get-NETBIOSName -DomainName $DomainName
	$DomainCreds = New-Object System.Management.Automation.PSCredential -ArgumentList "$domainNetBIOSName\$AdminUsername", $Pass

	configuration ConfigureWSFCNode1
	{
		Import-DscResource -ModuleName xDataKeeper, xFailOverCluster
		
		Node localhost
		{
			InstallLicense GetDKCELic
			{
				LicenseKeyFtpURL = $LicenseKeyFtpURL 
				RetryIntervalSec = $RetryIntervalSec
				RetryCount = $RetryCount 
			}

			Service StartExtMirr
			{
				Name = "extmirrsvc"
				StartupType = "Automatic"
				State = "Running"
				DependsOn = "[InstallLicense]GetDKCELic"
			}
			
			CreateJob NewJob
			{
				JobName 	= "Volume D"
				JobDesc 	= "Protection for SQL DATA and LOGS"
				SourceName 	= "WSFCNode1.datakeeper.local"
				SourceIP 	= "10.0.0.100"
				SourceVol 	= "D"
				TargetName 	= "WSFCNode2.datakeeper.local"
				TargetIP 	= "10.0.32.100"
				TargetVol 	= "D"
				SyncType	= "S"
				RetryIntervalSec = $RetryIntervalSec
				RetryCount		 = $RetryCount 
				DependsOn = "[Service]StartExtMirr"
			}

			xWaitForCluster WaitForWSFC
			{
				Name = $ClusterName
				RetryIntervalSec = $RetryIntervalSec
				RetryCount		 = $RetryCount 
				DependsOn = "[CreateMirror]NewMirror"
			}
		}
	}
	
	ConfigureWSFCNode1 -ConfigurationData $ConfigurationData
	Start-DscConfiguration -Path .\ConfigureWSFCNode1 -Wait -Verbose -ErrorVariable ev -Force
