param
(
    [Parameter(Mandatory)]
    [String]$DomainName,
    
    [Parameter(Mandatory)]
    [String]$AdminUsername,
    
    [Parameter(Mandatory)]
    [String]$AdminPassword,
    
    [Parameter(Mandatory)]
    [String]$LicenseKeyFtpURL,
            
    [Parameter(Mandatory)]
    [String]$ClusterName,
    
    [Parameter(Mandatory)]
    [String[]]$Nodes,
    
    [Parameter(Mandatory)]
    [String]$SourceIP,
    
    [Parameter(Mandatory)]
    [String]$TargetIP,
    
    [Parameter(Mandatory)]
    [String[]]$SQLServerIPAddresses,
            
    [Parameter(Mandatory)]
    [String[]]$SQLServerSubnetCidrs,
    
    [Parameter(Mandatory)]
    [String]$SQLSvcAccount,
    
    [Parameter(Mandatory)]
    [String]$SQLSvcAccountPassword,
    
    [Int]$RetryCount=30,
            
    [Int]$RetryIntervalSec=180	
)

function Get-NetBIOSName
{ 
    [OutputType([string])]
    param(
        [string]$DomainName
    )

    if ($DomainName.Contains('.')) {
        $length=$DomainName.IndexOf('.')
        if ( $length -ge 16) {
            $length=15
        }
        return $DomainName.Substring(0,$length)
    }
    else {
        if ($DomainName.Length -gt 15) {
            return $DomainName.Substring(0,15)
        }
        else {
            return $DomainName
        }
    }
}

function Add-TopLevelDomain
{ 
    [OutputType([string])]
    param(
        [string]$DomainName
    )

    if ($DomainName.Contains('.')) {
        return $DomainName
    }
    else {
        return ($DomainName + ".local")
    }
}

function toSubnetMask ($binary){
    $mask = ""
    
    for($i = 0; $i -lt 24; $i+=8) {
        $mask += [string]$([convert]::toInt32($binary.substring($i,8),2))
        $mask += "."
    }
    
    $mask += [string]$([convert]::toInt32($binary.substring(24,8),2))
    
    return $mask
}

function CidrToBinary ($cidr){
    if($cidr -le 32){
        [Int[]]$bits = (1..32)
        for($i=0;$i -lt $bits.length;$i++){
            if($bits[$i] -gt $cidr){
                $bits[$i]="0"
            } else {
                $bits[$i]="1"
            }
        }
        $cidr =$bits -join ""
    }
    return $cidr
}

function Get-SubnetMask ($IPv4cidr){
    [string[]]$cidr = $IPv4CIDR.split("/")
    return toSubnetMask( CidrToBinary( [convert]::ToInt32( $cidr[1],10 )))
}

try {
    $ErrorActionPreference = "Stop"
    
    Import-Module $psscriptroot\IPHelper.psm1
    
    Configuration LCMConfig {
        LocalConfigurationManager {
            RebootNodeIfNeeded = $true
            CertificateID = (Get-ChildItem Cert:\LocalMachine\My)[0].Thumbprint
        }
    }
    
    LCMConfig
    Set-DscLocalConfigurationManager -Path .\LCMConfig
    
    $ConfigurationData = @{
        AllNodes = @(
            @{
                NodeName = 'localhost'
				PSDscAllowDomainUser = $true
				CertificateFile = 'C:\DocumentEncryption.cer'
#                CertificateFile = 'C:\dsc.cer'
            }
        )
    }
    
    $Pass = ConvertTo-SecureString $AdminPassword -AsPlainText -Force
    $domainFQDN = Add-TopLevelDomain -DomainName $DomainName
    $domainNETBIOSName = Get-NETBIOSName -DomainName $DomainName
    $DomainCreds = New-Object System.Management.Automation.PSCredential -ArgumentList "$domainNetBIOSName\$AdminUsername", $Pass
    
    $SQLPass = ConvertTo-SecureString $SQLSvcAccountPassword -AsPlainText -Force
    $SQLSvcAccountCreds = New-Object System.Management.Automation.PSCredential ("$domainNetBIOSName\$SQLSvcAccount", $SQLPass)

    $node1 = $Nodes[0] + "." + $DomainFQDN
    $node2 = $Nodes[1] + "." + $DomainFQDN
    
    # Build strings needed for SQL silent install. The last one needs to be ip address of the node being added to the cluster.
    # Each string needs to be in the format <ipv4>;Cluster Network <int>;<4 octet subnet mask>
    # these get parsed in reverse order by the DSC module and then used as one long string.
    [string[]]$SQLServerIPs = New-Object string[] $SQLServerSubnetCidrs.Length
    $mask = ""
    for($i = 0; $i -lt $SQLServerSubnetCidrs.Length; $i++) {
        $mask = Get-SubnetMask($SQLServerSubnetCidrs[$i])
        $SQLServerIPs[$i] = "IPv4;" + $SQLServerIPAddresses[$i].split("/")[0] + ";" + "Cluster Network " + ($i + 1) + ";" + $mask
    }
   
    configuration ConfigureWSFCNode1
    {
        Import-DscResource -ModuleName xDataKeeper, xFailOverCluster, PSDesiredStateConfiguration
        
        Node localhost
        {
            InstallLicense GetDKCELic
            {
                LicenseKeyFtpURL = $LicenseKeyFtpURL 
                RetryIntervalSec = $RetryIntervalSec
                RetryCount = $RetryCount 
            }
    
            Service StartExtMirr
            {
                Name = "extmirrsvc"
                StartupType = "Automatic"
                State = "Running"
                DependsOn = "[InstallLicense]GetDKCELic"
            }
            
            CreateJob NewJob
            {
                JobName 	= "Volume D"
                JobDesc 	= "Protection for SQL DATA and LOGS"
                SourceName 	= $node1
                SourceIP 	= $SourceIP
                SourceVol 	= "D"
                TargetName 	= $node2
                TargetIP 	= $TargetIP
                TargetVol 	= "D"
                SyncType	= "S"
                RetryIntervalSec = $RetryIntervalSec
                RetryCount		 = $RetryCount 
                DependsOn = "[Service]StartExtMirr"
            }
    
            CreateMirror NewMirror
            {
                SourceIP 	= $SourceIP
                Volume	 	= "D"
                TargetIP 	= $TargetIP
                SyncType	= "S"
                RetryIntervalSec = $RetryIntervalSec
                RetryCount		 = $RetryCount 
                DependsOn = "[CreateJob]NewJob"
            }
            
            xWaitForCluster WaitForWSFC
            {
                Name = $ClusterName
                RetryIntervalSec = $RetryIntervalSec
                RetryCount		 = $RetryCount 
                DependsOn="[CreateMirror]NewMirror"
            }
            
            RegisterClusterVolume RegClusVol
            {
                Volume = "D"
                DependsOn = "[xWaitForCluster]WaitForWSFC"
            }
            
            InstallClusteredSQL INSTALLSQL
            {
                SQLServerClusterIP = $SQLServerIPs[0]
                AdminCredential = $DomainCreds
                SQLCredential = $SQLSvcAccountCreds
                DependsOn = "[RegisterClusterVolume]RegClusVol"
				PsDscRunAsCredential = $DomainCreds
            }
        }
    }

    ConfigureWSFCNode1 -ConfigurationData $ConfigurationData
    Start-DscConfiguration -Path .\ConfigureWSFCNode1 -Wait -Verbose -ErrorVariable ev -Force
} catch {
    Write-Verbose "$($_.exception.message)@ $(Get-Date)"
    $_ | Write-AWSQuickStartException
}