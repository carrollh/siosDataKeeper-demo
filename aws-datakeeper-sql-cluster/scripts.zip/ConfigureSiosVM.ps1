param
(
    [Parameter(Mandatory)]
    [String]$DomainName,

    [Parameter(Mandatory)]
	[String]$AdminUsername,
	
	[Parameter(Mandatory)]
	[String]$AdminPassword,

    [Parameter(Mandatory)]
    [String]$LicenseKeyFtpURL,

    [Int]$RetryCount=20,
            
    [Int]$RetryIntervalSec=60
)

function Get-NetBIOSName
{ 
    [OutputType([string])]
    param(
        [string]$DomainName
    )

    if ($DomainName.Contains('.')) {
        $length=$DomainName.IndexOf('.')
        if ( $length -ge 16) {
            $length=15
        }
        return $DomainName.Substring(0,$length)
    }
    else {
        if ($DomainName.Length -gt 15) {
            return $DomainName.Substring(0,15)
        }
        else {
            return $DomainName
        }
    }
}

function Add-TopLevelDomain
{ 
    [OutputType([string])]
    param(
        [string]$DomainName
    )

    if ($DomainName.Contains('.')) {
        return $DomainName
    }
    else {
        return ($DomainName + ".local")
    }
}

$ErrorActionPreference = "Stop"

Import-Module $psscriptroot\IPHelper.psm1

Configuration LCMConfig {
	LocalConfigurationManager {
		RebootNodeIfNeeded = $true
		CertificateID = (Get-ChildItem Cert:\LocalMachine\My)[0].Thumbprint
	}
}

LCMConfig
Set-DscLocalConfigurationManager -Path .\LCMConfig

$ConfigurationData = @{
	AllNodes = @(
		@{
			NodeName = 'localhost'
            PSDscAllowDomainUser = $true
			CertificateFile = 'C:\dsc.cer'
		}
	)
}

$Pass = ConvertTo-SecureString $AdminPassword -AsPlainText -Force
$domainFQDN = Add-TopLevelDomain -DomainName $DomainName
$domainNETBIOSName = Get-NETBIOSName -DomainName $DomainName
$DomainCreds = New-Object System.Management.Automation.PSCredential ("$domainNetBIOSName\$AdminUsername", $Pass)

configuration ConfigureSiosVM
{
    Import-DscResource -ModuleName cDisk, xActiveDirectory, xComputerManagement, xDataKeeper, xDisk, xNetworking, PSDesiredStateConfiguration
    
 	
    Node localhost
    {	
        xWaitforDisk Disk2
        {
            DiskNumber = 2
            RetryIntervalSec =$RetryIntervalSec
            RetryCount = $RetryCount
        }

        cDiskNoRestart DataDisk
        {
            DiskNumber = 2
            DriveLetter = "Z"
			DependsOn = "[xWaitforDisk]Disk2"
        }

        xDhcpClient DisabledDhcpClient
        {
            State          = 'Disabled'
            InterfaceAlias = 'Ethernet'
            AddressFamily  = 'IPv4'
        }
		
		xIPAddress PrivateIPAddress {
			IPAddress = '10.0.0.6'
			InterfaceAlias = 'Ethernet'
			PrefixLength = 24
			AddressFamily = 'IPv4'
		}
        
        xDnsServerAddress DnsServerAddress 
		{ 
			Address        = '10.0.0.4','10.0.0.2' 
			InterfaceAlias = 'Ethernet'
			AddressFamily  = 'IPv4'
			DependsOn = "[xIPAddress]PrivateIPAddress"
		}
        
        xDefaultGatewayAddress GatewayAddress
        {
            Address         = '10.0.0.1'
            InterfaceAlias = 'Ethernet'
			AddressFamily  = 'IPv4'
			DependsOn = "[xDnsServerAddress]DnsServerAddress"
        }
		
		xNetBIOS EnableNetBIOS {
			InterfaceAlias = 'Ethernet'
			Setting = 'Enable'
		}

        WindowsFeature NET35
        {
            Name = "WAS-NET-Environment"
            Ensure = "Present"
            DependsOn = "[xDefaultGatewayAddress]GatewayAddress"
        }
        
        WindowsFeature FC
        {
            Name = "Failover-Clustering"
            Ensure = "Present"
        }

        WindowsFeature FCMGMT
        {
            Name = "RSAT-Clustering-Mgmt"
            Ensure = "Present"
        }

        WindowsFeature FCPS
        {
            Name = "RSAT-Clustering-PowerShell"
            Ensure = "Present"
        }

        WindowsFeature ADPS
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
			DependsOn = "[xDnsServerAddress]DnsServerAddress"
        }
				
        xWaitForADDomain DscForestWait 
        { 
            DomainName = $domainFQDN 
            DomainUserCredential= $DomainCreds
            RetryCount = $RetryCount 
            RetryIntervalSec = $RetryIntervalSec 
            DependsOn = "[WindowsFeature]ADPS"
        }
				
        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $domainFQDN
            Credential = $DomainCreds
			DependsOn = "[xWaitForADDomain]DscForestWait"
        }
		
		InstallLicense GetDKCELic
		{
			LicenseKeyFtpURL = $LicenseKeyFtpURL 
            RetryIntervalSec = $RetryIntervalSec
			RetryCount = $RetryCount 
			DependsOn = "[xComputer]DomainJoin"
		}

		Service StartExtMirr
		{
			Name = "extmirrsvc"
			StartupType = "Automatic"
			State = "Running"
			DependsOn = "[InstallLicense]GetDKCELic"
		}
		
		AddClusteredSQLNode InstallSQL
		{
			AdminCredential = $DomainCreds
			DomainNetbiosName = $DomainNetbiosName
			DependsOn = "[Service]StartExtMirr"
		}
	
        LocalConfigurationManager 
        {
            RebootNodeIfNeeded = $true
        }

    }
}

ConfigureSiosVM -ConfigurationData $ConfigurationData
Start-DscConfiguration -Path .\ConfigureSiosVM -Wait -Verbose -ErrorVariable ev