param
(
    [Parameter(Mandatory)]
    [String]$DomainName,

    [Parameter(Mandatory)]
	[String]$AdminUsername,
	
	[Parameter(Mandatory)]
	[String]$AdminPassword,

    [Parameter(Mandatory)]
    [String]$LicenseKeyFtpURL,
	
	[Parameter(Mandatory)]
    [String]$ClusterName,
	
	[Parameter(Mandatory)]
    [String[]]$ClusterIPAddresses,
			
	[Parameter(Mandatory)]
	[String[]]$ClusterSubnetCidrs,
	
	[Parameter(Mandatory)]
	[String]$SQLSvcAccount,
	
	[Parameter(Mandatory)]
	[String]$SQLSvcAccountPassword,

    [Int]$RetryCount=10,
            
    [Int]$RetryIntervalSec=180
)
	
function Get-NetBIOSName
{ 
    [OutputType([string])]
    param(
        [string]$DomainName
    )

    if ($DomainName.Contains('.')) {
        $length=$DomainName.IndexOf('.')
        if ( $length -ge 16) {
            $length=15
        }
        return $DomainName.Substring(0,$length)
    }
    else {
        if ($DomainName.Length -gt 15) {
            return $DomainName.Substring(0,15)
        }
        else {
            return $DomainName
        }
    }
}

function Add-TopLevelDomain
{ 
    [OutputType([string])]
    param(
        [string]$DomainName
    )

    if ($DomainName.Contains('.')) {
        return $DomainName
    }
    else {
        return ($DomainName + ".local")
    }
}

function toSubnetMask ($binary){
	$mask = ""
	
	for($i = 0; $i -lt 24; $i+=8) {
		$mask += [string]$([convert]::toInt32($binary.substring($i,8),2))
		$mask += "."
	}
	
	$mask += [string]$([convert]::toInt32($binary.substring(24,8),2))
	
	return $mask
}

function CidrToBinary ($cidr){
    if($cidr -le 32){
        [Int[]]$bits = (1..32)
        for($i=0;$i -lt $bits.length;$i++){
            if($bits[$i] -gt $cidr){
				$bits[$i]="0"
			} else {
				$bits[$i]="1"
			}
        }
        $cidr =$bits -join ""
    }
    return $cidr
}

function Get-SubnetMask ($IPv4cidr){
	[string[]]$cidr = $IPv4CIDR.split("/")
	return toSubnetMask( CidrToBinary( [convert]::ToInt32( $cidr[1],10 )))
}

try {
	$ErrorActionPreference = "Continue"

	Import-Module $psscriptroot\IPHelper.psm1

	Configuration LCMConfig {
		LocalConfigurationManager {
			RebootNodeIfNeeded = $true
			CertificateID = (Get-ChildItem Cert:\LocalMachine\My)[0].Thumbprint
		}
	}

	LCMConfig
	Set-DscLocalConfigurationManager -Path .\LCMConfig

	$ConfigurationData = @{
		AllNodes = @(
			@{
				NodeName = 'localhost'
				CertificateFile = 'C:\dsc.cer'
			}
		)
	}
		
	$AdminPass = ConvertTo-SecureString $AdminPassword -AsPlainText -Force
	$domainFQDN = Add-TopLevelDomain -DomainName $DomainName
	$domainNETBIOSName = Get-NETBIOSName -DomainName $DomainName
	$DomainCreds = New-Object System.Management.Automation.PSCredential ("$domainNetBIOSName\$AdminUsername", $AdminPass)
	$DomainFQDNCreds = New-Object System.Management.Automation.PSCredential ("$domainFQDN\$AdminUsername", $AdminPass)
	
	$SQLPass = ConvertTo-SecureString $SQLSvcAccountPassword -AsPlainText -Force
	$SQLSvcAccountCreds = New-Object System.Management.Automation.PSCredential ("$domainNetBIOSName\$SQLSvcAccount", $SQLPass)

	configuration ConfigureWSFCNode2
	{
		Import-DscResource -ModuleName xDataKeeper, xFailOverCluster
		
		Node localhost
		{
			InstallLicense GetDKCELic
			{
				LicenseKeyFtpURL = $LicenseKeyFtpURL 
				RetryIntervalSec = $RetryIntervalSec
				RetryCount = $RetryCount 
			}
		
			Service StartExtMirr
			{
				Name = "extmirrsvc"
				StartupType = "Automatic"
				State = "Running"
				DependsOn = "[InstallLicense]GetDKCELic"
			}
					
			xWaitForCluster WaitForWSFC
			{
				Name = $ClusterName
				RetryIntervalSec = $RetryIntervalSec
				RetryCount		 = $RetryCount 
				DependsOn = "[Service]StartExtMirr"
			}
            
			WaitForClusterGroup WaitForGroup
			{
				Name = "SQL Server (MSSQLSERVER)"
				RetryIntervalSec = $RetryIntervalSec
				RetryCount		 = $RetryCount 
				DependsOn = "[xWaitForCluster]WaitForWSFC"
			}
        }
    }
            
    # Build strings needed for SQL silent install. The last one needs to be ip address of the node being added to the cluster.
	# Each string needs to be in the format <ipv4>;Cluster Network <int>;<4 octet subnet mask>
	# these get parsed in reverse order by the DSC module and then used as one long string.
	[string[]]$ClusterAddresses = New-Object string[] $ClusterSubnetCidrs.Length
	$mask = ""
	for($i = 0; $i -lt $ClusterSubnetCidrs.Length; $i++) {
		$mask = Get-SubnetMask($ClusterSubnetCidrs[$i])
		$ClusterAddresses[$i] = "IPv4;" + $ClusterIPAddresses[$i].split("/")[0] + ";" + "Cluster Network " + ($i + 1) + ";" + $mask
	}
            
    $SQLUser = $SQLSvcAccountCreds.UserName
    $SQLPass = $SQLSvcAccountCreds.GetNetworkCredential().Password
    
    $logfile = "C:\Windows\Temp\datakeeperSQLinstall.txt"
    $results = ""
    while(-Not $results.Contains("Success")) {
        $results = C:\\SQL2014\\setup /ACTION="AddNode" /SkipRules=Cluster_VerifyForErrors Cluster_IsWMIServiceOperational /ENU="True" /Q /UpdateEnabled="False" /ERRORREPORTING="False" /USEMICROSOFTUPDATE="False" /UpdateSource="MU" /HELP="False" /INDICATEPROGRESS="False" /X86="False" /INSTANCENAME="MSSQLSERVER" /SQMREPORTING="False" /FAILOVERCLUSTERGROUP="SQL Server (MSSQLSERVER)" /CONFIRMIPDEPENDENCYCHANGE="True" /FAILOVERCLUSTERIPADDRESSES="$ClusterAddresses" /FAILOVERCLUSTERNETWORKNAME="siossqlserver" /AGTSVCACCOUNT=$SQLUser /SQLSVCACCOUNT=$SQLUser /FTSVCACCOUNT="NT Service\MSSQLFDLauncher" /SQLSVCPASSWORD=$SQLPass /AGTSVCPASSWORD=$SQLPass /IAcceptSQLServerLicenseTerms
        $results >> $logfile
    }
    
	ConfigureWSFCNode2 -ConfigurationData $ConfigurationData
	Start-DscConfiguration -Path .\ConfigureWSFCNode2 -Wait -Verbose -ErrorVariable ev -Force
}
catch {
    Write-Verbose "$($_.exception.message)@ $(Get-Date)"
    $_ | Write-AWSQuickStartException
}
