[CmdletBinding()]
param(
    [string]
    $username
)

$ErrorActionPreference = "Stop"

Write-Verbose "Resetting built-in administrator username"
$user = Get-WMIObject Win32_UserAccount | where -Property Name -eq Administrator
$user.Rename($username)
