param
(
	[Parameter(Mandatory)]
	[String]$DomainName,

	[Parameter(Mandatory)]
	[String]$AdminUsername,
	
	[Parameter(Mandatory)]
	[String]$AdminPassword,
	
	[Parameter(Mandatory)]
	[String]$LicenseKeyFtpURL,
			
	[Parameter(Mandatory)]
	[String]$ClusterName,

	[Parameter(Mandatory)]
	[String[]]$Nodes,

	[Int]$RetryCount=20,
			
	[Int]$RetryIntervalSec=30		 
)
	
function Get-NetBIOSName
{ 
    [OutputType([string])]
    param(
        [string]$DomainName
    )

    if ($DomainName.Contains('.')) {
        $length=$DomainName.IndexOf('.')
        if ( $length -ge 16) {
            $length=15
        }
        return $DomainName.Substring(0,$length)
    }
    else {
        if ($DomainName.Length -gt 15) {
            return $DomainName.Substring(0,15)
        }
        else {
            return $DomainName
        }
    }
}

function Add-TopLevelDomain
{ 
    [OutputType([string])]
    param(
        [string]$DomainName
    )

    if ($DomainName.Contains('.')) {
        return $DomainName
    }
    else {
        return ($DomainName + ".local")
    }
}

$ErrorActionPreference = "Stop"

Import-Module $psscriptroot\IPHelper.psm1

Configuration LCMConfig {
	LocalConfigurationManager {
		RebootNodeIfNeeded = $true
		CertificateID = (Get-ChildItem Cert:\LocalMachine\My)[0].Thumbprint
	}
}

LCMConfig
Set-DscLocalConfigurationManager -Path .\LCMConfig

$ConfigurationData = @{
	AllNodes = @(
		@{
			NodeName = 'localhost'
            PSDscAllowDomainUser = $true
			CertificateFile = 'C:\dsc.cer'
		}
	)
}
	
$Pass = ConvertTo-SecureString $AdminPassword -AsPlainText -Force
$domainFQDN = Add-TopLevelDomain -DomainName $DomainName
$domainNETBIOSName = Get-NETBIOSName -DomainName $DomainName
$SharePath = $domainNetBIOSName + "-fsw"
$DomainCreds = New-Object System.Management.Automation.PSCredential ("$domainNetBIOSName\$AdminUsername", $Pass)
$DomainFQDNCreds = New-Object System.Management.Automation.PSCredential ("$domainFQDN\$AdminUsername", $Pass)

$node0 = $Nodes[0] + "." + $domainFQDN	
$node1 = $Nodes[1] + "." + $domainFQDN

configuration ConfigureSiosVM0
{
    Import-DscResource -ModuleName cDisk, xActiveDirectory, xComputerManagement, xDataKeeper, xDisk, xFailOverCluster, xNetworking, PSDesiredStateConfiguration
	
    Node localhost
    {
        xWaitforDisk Disk2
        {
             DiskNumber = 2
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
        }

        cDiskNoRestart DataDisk
        {
            DiskNumber = 2
            DriveLetter = "F"
        }
		
		xIPAddress PrivateIPAddress {
			IPAddress = '10.0.0.5'
			InterfaceAlias = 'Ethernet'
			PrefixLength = 24
			AddressFamily = 'IPv4'
		}
		
		xDnsServerAddress DnsServerAddress 
		{ 
			Address        = '10.0.0.4' 
			InterfaceAlias = 'Ethernet'
			AddressFamily  = 'IPv4'
			DependsOn = "[xIPAddress]PrivateIPAddress"
		}

        WindowsFeature NET35
        {
            Name = "WAS-NET-Environment"
            Ensure = "Present"
        }
        
        WindowsFeature FC
        {
            Name = "Failover-Clustering"
            Ensure = "Present"
        }

		WindowsFeature FCMGMT
		{
			Name = "RSAT-Clustering-Mgmt"
			Ensure = "Present"
		}

        WindowsFeature FCPS
        {
            Name = "RSAT-Clustering-PowerShell"
            Ensure = "Present"
        }

        WindowsFeature ADPS
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
			DependsOn = "[xDnsServerAddress]DnsServerAddress"
        }
				
        xWaitForADDomain DscForestWait 
        { 
            DomainName = $domainFQDN 
            DomainUserCredential= $DomainCreds
            RetryCount = $RetryCount 
            RetryIntervalSec = $RetryIntervalSec 
			DependsOn = "[WindowsFeature]ADPS"
		}
				
        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $domainFQDN
            Credential = $DomainCreds
			DependsOn = "[xWaitForADDomain]DscForestWait"
        }
		
		InstallDKCE InstallDataKeeper
		{
			InstallerPath = "$env:windir\Temp\DK-Setup.exe"
			SetupFilePath = "$env:windir\Temp\setup.iss"
			AdminCredential = $DomainCreds
			DependsOn = "[xComputer]DomainJoin"
		}
		
		InstallLicense GetDKCELic
		{
			LicenseKeyFtpURL = $LicenseKeyFtpURL 
            RetryIntervalSec = $RetryIntervalSec
			RetryCount = $RetryCount 
			DependsOn = "[InstallDKCE]InstallDataKeeper"
		}
		
		Service StartExtMirr
		{
			Name = "extmirrsvc"
			StartupType = "Automatic"
			State = "Running"
			DependsOn = "[InstallLicense]GetDKCELic"
		}

		CreateJob NewJob
		{
			JobName 	= "Volume F"
			JobDesc 	= "Protection for SQL DATA and LOGS"
			SourceName 	= $node0
			SourceIP 	= "10.0.0.5"
			SourceVol 	= "F"
			TargetName 	= $node1
			TargetIP 	= "10.0.0.6"
			TargetVol 	= "F"
			SyncType	= "A"
			RetryIntervalSec = 20 
			RetryCount		 = 30 
			DependsOn = "[Service]StartExtMirr"
		}

		CreateMirror NewMirror
		{
			SourceIP 	= "10.0.0.5"
			Volume	 	= "F"
			TargetIP 	= "10.0.0.6"
			SyncType	= "S"
			RetryIntervalSec = 20 
			RetryCount		 = 30
			DependsOn = "[CreateJob]NewJob"
		}

		xCluster FailoverCluster
        {
            Name = $ClusterName
            DomainAdministratorCredential = $DomainCreds
			Nodes = $Nodes
			DependsOn="[CreateMirror]NewMirror"
        }

        xWaitForFileShareWitness WaitForFSW
        {
            SharePath = $SharePath
            DomainAdministratorCredential = $DomainCreds
        }

        xClusterQuorum FailoverClusterQuorum
        {
            Name = $ClusterName
            SharePath = $SharePath
            DomainAdministratorCredential = $DomainCreds
			DependsOn = "[xWaitForFileShareWitness]WaitForFSW", "[xCluster]FailoverCluster"
        }
		
		RegisterClusterVolume RegClusVol
		{
			Volume = "F"
			DependsOn = "[xClusterQuorum]FailoverClusterQuorum"
		}
		
		InstallClusteredSQL InstallSQL
		{
			AdminCredential = $DomainCreds
			DomainNetbiosName = $domainNetBIOSName
			DependsOn = "[RegisterClusterVolume]RegClusVol"
		}
				
		SetSQLServerIP ResetSQLIP
		{
			InternalLoadBalancerIP = "10.0.0.200"
			DependsOn = "[InstallClusteredSQL]InstallSQL"
		}
			
        LocalConfigurationManager 
        {
            RebootNodeIfNeeded = $true
        }
    }
}

ConfigureSiosVM0 -ConfigurationData $ConfigurationData
Start-DscConfiguration -Path .\ConfigureSiosVM0 -Wait -Verbose -ErrorVariable ev

