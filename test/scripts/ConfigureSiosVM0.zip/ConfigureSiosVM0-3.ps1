configuration ConfigureSiosVM0
{
    param
    (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$AdminCreds,

        [String]$DomainNetbiosName=(Get-NetBIOSName -DomainName $DomainName),

		[Parameter(Mandatory)]
        [String]$ClusterName,

        [Parameter(Mandatory)]
        [String]$SharePath
    )

    Import-DscResource -ModuleName xDataKeeper, xFailOverCluster
    
	try {
		$ErrorActionPreference = "Continue"
		Start-Transcript -Path "$env:winder\Temp\ConfigureSiosVM0-3.ps1.txt" -Append
		
		[System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainNetbiosName}\$($AdminCreds.UserName)", $AdminCreds.Password)
		
        Node localhost
		{
			xWaitForFileShareWitness WaitForFSW
			{
				SharePath = $SharePath
				DomainAdministratorCredential = $DomainCreds
			}

			xClusterQuorum FailoverClusterQuorum
			{
				Name = $ClusterName
				SharePath = $SharePath
				DomainAdministratorCredential = $DomainCreds
				DependsOn = "[xWaitForFileShareWitness]WaitForFSW"
			}

			RegisterClusterVolume RegClusVol
			{
				Volume = "F"
				DependsOn = "[xClusterQuorum]FailoverClusterQuorum"
			}	
          
			DownloadSQLServer GetSQL
			{
				SQLServerURL = "http://care.dlservice.microsoft.com/dl/download/2/F/8/2F8F7165-BB21-4D1E-B5D8-3BD3CE73C77D/SQLServer2014SP1-FullSlipstream-x64-ENU.iso"
				ISODownloadPath = "$env:windir\Temp\"
				FinalPathToFiles = "C:\SQL2014\"
				DependsOn = "[RegisterClusterVolume]RegClusVol"
				PsDscRunAsCredential = $DomainCreds
			}

			DownloadSSMS GetSSMS
			{
				SSMSURL = "http://download.microsoft.com/download/E/E/1/EE12CC0F-A1A5-4B55-9425-2AFBB2D63979/SSMS-Full-Setup.exe"
				DownloadPath = "$env:windir\Temp\"
				DependsOn = "[DownloadSQLServer]GetSQL"
				PsDscRunAsCredential = $DomainCreds
			}
			
			InstallSSMS PutSSMS
			{
				FullPathToExe = "$env:windir\Temp\SSMS-Full-Setup.exe"
				DependsOn = "[DownloadSSMS]GetSSMS"
				PsDscRunAsCredential = $DomainCreds
			}

			InstallClusteredSQL InstallSQL
			{
				AdminCredential = $DomainCreds
				DomainNetbiosName = $DomainNetbiosName
				DependsOn = "[InstallSSMS]PutSSMS"
				PsDscRunAsCredential = $DomainCreds
			}
					
			SetSQLServerIP ResetSQLIP
			{
				InternalLoadBalancerIP = "10.0.0.200"
				DependsOn = "[InstallClusteredSQL]InstallSQL"
			}
		
			LocalConfigurationManager 
			{
				RebootNodeIfNeeded = $true
			}
		}
	} 
    catch {}
    finally {
		Stop-Transcript
	}
}

function Get-NetBIOSName
{ 
    [OutputType([string])]
    param(
        [string]$DomainName
    )

    if ($DomainName.Contains('.')) {
        $length=$DomainName.IndexOf('.')
        if ( $length -ge 16) {
            $length=15
        }
        return $DomainName.Substring(0,$length)
    }
    else {
        if ($DomainName.Length -gt 15) {
            return $DomainName.Substring(0,15)
        }
        else {
            return $DomainName
        }
    }
}
