configuration ConfigureSiosClientVM
{
    param
    (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [String]$DomainNetbiosName=(Get-NetBIOSName -DomainName $DomainName),

        [Int]$RetryCount=20,
				
        [Int]$RetryIntervalSec=30
    )

	Import-DscResource -ModuleName xActiveDirectory, xComputerManagement
    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainNetbiosName}\$($Admincreds.UserName)", $Admincreds.Password)
    
    Node localhost
    {
        WindowsFeature ADPS
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        }
				
        xWaitForADDomain DscForestWait 
        { 
            DomainName = $DomainName 
            DomainUserCredential= $DomainCreds
            RetryCount = $RetryCount 
            RetryIntervalSec = $RetryIntervalSec 
			DependsOn = "[WindowsFeature]ADPS"
        }
				
        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $DomainCreds
			DependsOn = "[xWaitForADDomain]DscForestWait"
        }

		Script RegClusVol
		{
			SetScript = {
				$logfile = "C:\Windows\Temp\datakeepersqlmanagementstudio.txt"
				"Installing SQL mgmt tools" | OutFile -FilePath $logfile -Encoding "UTF8" -Force			
				
				while($(Get-Service winmgmt).Status -ne "Running") {
					Start-Sleep 30
				}
				
				$results = C:\SQL2014\setup.exe /ACTION="Install" /UpdateEnabled="False" /ERRORREPORTING="False" /USEMICROSOFTUPDATE="False" /IACCEPTSQLSERVERLICENSETERMS /Q /INDICATEPROGRESS /FEATURES="Tools"
			
				Add-Content $logfile ("SQL Management Studio Install: " + $results)
			}
			TestScript = { $false }
			GetScript = {@{}}
			Credential = $Admincreds
			DependsOn = "[xComputer]DomainJoin"
		}
		
        LocalConfigurationManager 
        {
            RebootNodeIfNeeded = $true
        }
    }
}

function Get-NetBIOSName
{ 
    [OutputType([string])]
    param(
        [string]$DomainName
    )

    if ($DomainName.Contains('.')) {
        $length=$DomainName.IndexOf('.')
        if ( $length -ge 16) {
            $length=15
        }
        return $DomainName.Substring(0,$length)
    }
    else {
        if ($DomainName.Length -gt 15) {
            return $DomainName.Substring(0,15)
        }
        else {
            return $DomainName
        }
    }
}