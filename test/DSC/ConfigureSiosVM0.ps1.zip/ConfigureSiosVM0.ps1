configuration ConfigureSiosVM0
{
    param
    (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [String]$DomainNetbiosName=(Get-NetBIOSName -DomainName $DomainName),

		[Parameter(Mandatory)]
        [String]$LicenseKeyFtpURL,
				
		[Parameter(Mandatory)]
        [String]$ClusterName,

        [Parameter(Mandatory)]
        [String]$SharePath,

        [Parameter(Mandatory)]
        [String[]]$Nodes,

        [Int]$RetryCount=20,
				
        [Int]$RetryIntervalSec=30		 
    )

	$node0 = "sios-0." + $DomainName	
	$node1 = "sios-1." + $DomainName

    Import-DscResource -ModuleName cDisk, xActiveDirectory, xComputerManagement, xDataKeeper, xDisk, xFailOverCluster, xNetworking
    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainNetbiosName}\$($Admincreds.UserName)", $Admincreds.Password)
    
    Enable-CredSSPNTLM -DomainName $DomainName

    Node localhost
    {
        xWaitforDisk Disk2
        {
             DiskNumber = 2
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
        }

        cDiskNoRestart DataDisk
        {
            DiskNumber = 2
            DriveLetter = "F"
        }

        WindowsFeature FC
        {
            Name = "Failover-Clustering"
            Ensure = "Present"
        }

		WindowsFeature FCMGMT
		{
			Name = "RSAT-Clustering-Mgmt"
			Ensure = "Present"
		}

        WindowsFeature FCPS
        {
            Name = "RSAT-Clustering-PowerShell"
            Ensure = "Present"
        }

        WindowsFeature ADPS
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        }
				
        xWaitForADDomain DscForestWait 
        { 
            DomainName = $DomainName 
            DomainUserCredential= $DomainCreds
            RetryCount = $RetryCount 
            RetryIntervalSec = $RetryIntervalSec 
			DependsOn = "[WindowsFeature]ADPS"
		}
				
        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $DomainCreds
			DependsOn = "[xWaitForADDomain]DscForestWait"
        }

		InstallLicense GetDKCELic
		{
			LicenseKeyFtpURL = $LicenseKeyFtpURL 
            RetryIntervalSec = $RetryIntervalSec
			RetryCount = $RetryCount 
			DependsOn = "[xComputer]DomainJoin"
		}
		
		sService StartExtMirr
		{
			Name = "extmirrsvc"
			StartupType = "Automatic"
			State = "Running"
			DependsOn = "[InstallLicense]GetDKCELic"
		}

		CreateJob NewJob
		{
			JobName 	= "Volume F Replication"
			JobDesc 	= "Protection for File Server Role"
			SourceName 	= $node0
			SourceIP 	= "10.0.0.5"
			SourceVol 	= "F"
			TargetName 	= $node1
			TargetIP 	= "10.0.0.6"
			TargetVol 	= "F"
			SyncType	= "A"
			RetryIntervalSec = 20 
			RetryCount		 = 30 
			DependsOn = "[sService]StartExtMirr"
		}

		CreateMirror NewMirror
		{
			SourceIP 	= "10.0.0.5"
			Volume	 	= "F"
			TargetIP 	= "10.0.0.6"
			SyncType	= "S"
			RetryIntervalSec = 20 
			RetryCount		 = 30
			DependsOn = "[CreateJob]NewJob"
		}

		xCluster FailoverCluster
        {
            Name = $ClusterName
            DomainAdministratorCredential = $DomainCreds
			Nodes = $Nodes
			DependsOn="[CreateMirror]NewMirror"
        }

        xWaitForFileShareWitness WaitForFSW
        {
            SharePath = $SharePath
            DomainAdministratorCredential = $DomainCreds
        }

        xClusterQuorum FailoverClusterQuorum
        {
            Name = $ClusterName
            SharePath = $SharePath
            DomainAdministratorCredential = $DomainCreds
        }
		
		RegisterClusterVolume RegClusVol
		{
			Volume = "F"
			DependsOn = "[xCluster]FailoverCluster"
		}
		
		Script InstallSQL
		{
			SetScript = {
				
				Set-NetFirewallProfile -Profile Domain,Public,Private -Enabled False
				
				mkdir C:\TempDB
				
				while($(Get-Service winmgmt).Status -ne "Running") {
					Start-Sleep 10
				}
				
				$sqluseraccount = $(Get-NetBIOSName) + "\siosadmin"
				$results = C:\SQL2014\setup /ACTION="InstallFailoverCluster" /SkipRules=Cluster_VerifyForErrors Cluster_IsWMIServiceOperational /ENU="True" /Q /UpdateEnabled="False" /ERRORREPORTING="False" /USEMICROSOFTUPDATE="False" /FEATURES=SQLENGINE,REPLICATION,FULLTEXT,DQ,SSMS,ADV_SSMS /UpdateSource="MU" /HELP="False" /INDICATEPROGRESS="False" /X86="False" /INSTALLSHAREDDIR="C:\Program Files\Microsoft SQL Server" /INSTALLSHAREDWOWDIR="C:\Program Files (x86)\Microsoft SQL Server" /INSTANCENAME="MSSQLSERVER" /SQMREPORTING="False" /INSTANCEID="MSSQLSERVER" /INSTANCEDIR="C:\Program Files\Microsoft SQL Server" /FAILOVERCLUSTERDISKS="DataKeeper Volume F" /FAILOVERCLUSTERGROUP="SQL Server (MSSQLSERVER)" /FAILOVERCLUSTERIPADDRESSES="IPv4;10.0.0.200;Cluster Network 1;255.255.255.0" /FAILOVERCLUSTERNETWORKNAME="siossqlserver" /AGTSVCACCOUNT=$sqluseraccount /COMMFABRICPORT="0" /COMMFABRICNETWORKLEVEL="0" /COMMFABRICENCRYPTION="0" /MATRIXCMBRICKCOMMPORT="0" /FILESTREAMLEVEL="0" /SQLCOLLATION="SQL_Latin1_General_CP1_CI_AS" /SQLSVCACCOUNT=$sqluseraccount /SQLSYSADMINACCOUNTS=$sqluseraccount /INSTALLSQLDATADIR="F:" /SQLTEMPDBDIR="C:\TempDB" /FTSVCACCOUNT="NT Service\MSSQLFDLauncher" /SQLSVCPASSWORD="SIOS!5105" /AGTSVCPASSWORD="SIOS!5105" /IAcceptSQLServerLicenseTerms 2>"C:\Windows\Temp\datakeeperInstallSQLFAILURE.txt"
				$results | Out-File -FilePath $logfile -Encoding "UTF8" -Force
			}

			TestScript = { $false }
			GetScript = {@{}}
			Credential = $AdminCreds
			DependsOn = "[RegisterClusterVolume]RegClusVol"
		}
		
        LocalConfigurationManager 
        {
            RebootNodeIfNeeded = $true
        }
    }
}

function Get-NetBIOSName
{ 
    [OutputType([string])]
    param(
        [string]$DomainName
    )

    if ($DomainName.Contains('.')) {
        $length=$DomainName.IndexOf('.')
        if ( $length -ge 16) {
            $length=15
        }
        return $DomainName.Substring(0,$length)
    }
    else {
        if ($DomainName.Length -gt 15) {
            return $DomainName.Substring(0,15)
        }
        else {
            return $DomainName
        }
    }
}

function Enable-CredSSPNTLM
{ 
    param(
        [Parameter(Mandatory=$true)]
        [string]$DomainName
    )
    
    # This is needed for the case where NTLM authentication is used

    Write-Verbose 'STARTED:Setting up CredSSP for NTLM'
   
    Enable-WSManCredSSP -Role client -DelegateComputer localhost, *.$DomainName -Force -ErrorAction SilentlyContinue
    Enable-WSManCredSSP -Role server -Force -ErrorAction SilentlyContinue

    if(-not (Test-Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -ErrorAction SilentlyContinue))
    {
        New-Item -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows -Name '\CredentialsDelegation' -ErrorAction SilentlyContinue
    }

    if( -not (Get-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -Name 'AllowFreshCredentialsWhenNTLMOnly' -ErrorAction SilentlyContinue))
    {
        New-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -Name 'AllowFreshCredentialsWhenNTLMOnly' -value '1' -PropertyType dword -ErrorAction SilentlyContinue
    }

    if (-not (Get-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -Name 'ConcatenateDefaults_AllowFreshNTLMOnly' -ErrorAction SilentlyContinue))
    {
        New-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -Name 'ConcatenateDefaults_AllowFreshNTLMOnly' -value '1' -PropertyType dword -ErrorAction SilentlyContinue
    }

    if(-not (Test-Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -ErrorAction SilentlyContinue))
    {
        New-Item -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -Name 'AllowFreshCredentialsWhenNTLMOnly' -ErrorAction SilentlyContinue
    }

    if (-not (Get-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name '1' -ErrorAction SilentlyContinue))
    {
        New-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name '1' -value "wsman/$env:COMPUTERNAME" -PropertyType string -ErrorAction SilentlyContinue
    }

    if (-not (Get-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name '2' -ErrorAction SilentlyContinue))
    {
        New-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name '2' -value "wsman/localhost" -PropertyType string -ErrorAction SilentlyContinue
    }

    if (-not (Get-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name '3' -ErrorAction SilentlyContinue))
    {
        New-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name '3' -value "wsman/*.$DomainName" -PropertyType string -ErrorAction SilentlyContinue
    }

    Write-Verbose "DONE:Setting up CredSSP for NTLM"
}