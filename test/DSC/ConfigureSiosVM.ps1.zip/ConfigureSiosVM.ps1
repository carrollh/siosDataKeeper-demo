configuration ConfigureSiosVM
{
    param
    (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [String]$DomainNetbiosName=(Get-NetBIOSName -DomainName $DomainName),

		[Parameter(Mandatory)]
        [String]$LicenseKeyFtpURL,

        [Int]$RetryCount=20,
				
        [Int]$RetryIntervalSec=30
    )

    Import-DscResource -ModuleName cDisk, xActiveDirectory, xComputerManagement, xDataKeeper, xDisk, xNetworking
    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainNetbiosName}\$($Admincreds.UserName)", $Admincreds.Password)
    
    Node localhost
    {
        xWaitforDisk Disk2
        {
             DiskNumber = 2
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
        }

        cDiskNoRestart DataDisk
        {
            DiskNumber = 2
            DriveLetter = "F"
        }

        WindowsFeature FC
        {
            Name = "Failover-Clustering"
            Ensure = "Present"
        }

		WindowsFeature FCMGMT
		{
			Name = "RSAT-Clustering-Mgmt"
			Ensure = "Present"
		}

        WindowsFeature FCPS
        {
            Name = "RSAT-Clustering-PowerShell"
            Ensure = "Present"
        }

        WindowsFeature ADPS
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        }
				
        xWaitForADDomain DscForestWait 
        { 
            DomainName = $DomainName 
            DomainUserCredential= $DomainCreds
            RetryCount = $RetryCount 
            RetryIntervalSec = $RetryIntervalSec 
			DependsOn = "[WindowsFeature]ADPS"
        }
				
        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $DomainCreds
			DependsOn = "[xWaitForADDomain]DscForestWait"
        }

		InstallLicense GetDKCELic
		{
			LicenseKeyFtpURL = $LicenseKeyFtpURL 
            RetryIntervalSec = $RetryIntervalSec
			RetryCount = $RetryCount 
			DependsOn = "[xComputer]DomainJoin"
		}

		sService StartExtMirr
		{
			Name = "extmirrsvc"
			StartupType = "Automatic"
			State = "Running"
			DependsOn = "[InstallLicense]GetDKCELic"
		}
		
		Script NewTempDir
		{
			SetScript = {
				mkdir C:\TempDB
				
				$logfile = "C:\Windows\Temp\datakeeperregistervol.txt"
				"Installing SQL Server /AddNode" | OutFile -FilePath $logfile -Encoding "UTF8" -Force
				
				
				
				while($(Get-ClusterResource "SQL Server").State -ne "Running") {
					Start-Sleep 60
				}
				
				$results = C:\SQL2014\setup /ACTION="AddNode" /ENU="True" /Q /UpdateEnabled="False" /ERRORREPORTING="False" /USEMICROSOFTUPDATE="False" /UpdateSource="MU" /HELP="False" /INDICATEPROGRESS="False" /X86="False" /INSTANCENAME="MSSQLSERVER" /SQMREPORTING="False" /FAILOVERCLUSTERGROUP="SQL Server (MSSQLSERVER)" /CONFIRMIPDEPENDENCYCHANGE="False" /FAILOVERCLUSTERIPADDRESSES="IPv4;10.0.0.200;Cluster Network 1;255.255.255.0" /FAILOVERCLUSTERNETWORKNAME="siossqlserver" /AGTSVCACCOUNT="$DomainNetbiosName\siosadmin" /SQLSVCACCOUNT="$DomainNetbiosName\siosadmin" /FTSVCACCOUNT="NT Service\MSSQLFDLauncher" /SQLSVCPASSWORD="SIOS!5105" /AGTSVCPASSWORD="SIOS!5105" /IAcceptSQLServerLicenseTerms /SkipRules=Cluster_VerifyForErrors
				
				Add-Content $logfile ("SQL Install: " + $results)
				
				Start-Sleep 60
			}

			TestScript = { $false }
			GetScript = {@{}}
			Credential = $AdminCreds
		}

        LocalConfigurationManager 
        {
            RebootNodeIfNeeded = $true
        }

    }
}

function Get-NetBIOSName
{ 
    [OutputType([string])]
    param(
        [string]$DomainName
    )

    if ($DomainName.Contains('.')) {
        $length=$DomainName.IndexOf('.')
        if ( $length -ge 16) {
            $length=15
        }
        return $DomainName.Substring(0,$length)
    }
    else {
        if ($DomainName.Length -gt 15) {
            return $DomainName.Substring(0,15)
        }
        else {
            return $DomainName
        }
    }
}
