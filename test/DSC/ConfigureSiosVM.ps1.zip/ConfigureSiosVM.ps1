configuration ConfigureSiosVM
{
    param
    (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [String]$DomainNetbiosName=(Get-NetBIOSName -DomainName $DomainName),

		[Parameter(Mandatory)]
        [String]$LicenseKeyFtpURL,

        [Int]$RetryCount=20,
				
        [Int]$RetryIntervalSec=30
    )

    Import-DscResource -ModuleName cDisk, xActiveDirectory, xComputerManagement, xDataKeeper, xDisk, xNetworking, xSQL, xSQLServer
    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainNetbiosName}\$($Admincreds.UserName)", $Admincreds.Password)
    
	Enable-CredSSPNTLM -DomainName $DomainName
	
    Node localhost
    {
        xWaitforDisk Disk2
        {
             DiskNumber = 2
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
        }

        cDiskNoRestart DataDisk
        {
            DiskNumber = 2
            DriveLetter = "F"
        }

        WindowsFeature FC
        {
            Name = "Failover-Clustering"
            Ensure = "Present"
        }

		WindowsFeature FCMGMT
		{
			Name = "RSAT-Clustering-Mgmt"
			Ensure = "Present"
		}

        WindowsFeature FCPS
        {
            Name = "RSAT-Clustering-PowerShell"
            Ensure = "Present"
        }

        WindowsFeature ADPS
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        }
				
        xWaitForADDomain DscForestWait 
        { 
            DomainName = $DomainName 
            DomainUserCredential= $DomainCreds
            RetryCount = $RetryCount 
            RetryIntervalSec = $RetryIntervalSec 
			DependsOn = "[WindowsFeature]ADPS"
        }
				
        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $DomainCreds
			DependsOn = "[xWaitForADDomain]DscForestWait"
        }

		InstallLicense GetDKCELic
		{
			LicenseKeyFtpURL = $LicenseKeyFtpURL 
            RetryIntervalSec = $RetryIntervalSec
			RetryCount = $RetryCount 
			DependsOn = "[xComputer]DomainJoin"
		}

		sService StartExtMirr
		{
			Name = "extmirrsvc"
			StartupType = "Automatic"
			State = "Running"
			DependsOn = "[InstallLicense]GetDKCELic"
		}
		
		Script InstallSQL
		{
			SetScript = {
				mkdir C:\TempDB
				
				while($true) {
					$job = & "$env:extmirrbase\emcmd.exe" . GETJOBINFO
					if($job -ne $NULL) {
						$job | Out-File -FilePath "C:\Windows\datakeeperJOB.txt" -Encoding "UTF8" -Force
						break
					} else {
						Start-Sleep 5
					}
				}
				
				$results = Enable-WSManCredSSP -Role client -DelegateComputer localhost, *.$DomainName -Force -ErrorAction SilentlyContinue 2>"C:\Windows\Temp\datakeeperWMI1Error.log"
				$logfile = "C:\Windows\Temp\datakeeperWMI1.log"
				$results | Out-File -FilePath $logfile -Encoding "UTF8" -Force
				
				$results = Enable-WSManCredSSP -Role server -Force -ErrorAction SilentlyContinue 2>"C:\Windows\Temp\datakeeperWMI2Error.log"
				$logfile = "C:\Windows\Temp\datakeeperWMI2.log"
				$results | Out-File -FilePath $logfile -Encoding "UTF8" -Force
				
				# things that make sure WMI is working
				$results = netsh firewall set service RemoteAdmin enable
				$logfile = "C:\Windows\Temp\datakeeperWMI3.log"
				$results | Out-File -FilePath $logfile -Encoding "UTF8" -Force
				
				$logfile = "C:\Windows\Temp\datakeeperWMI10.txt"
				$results = & "$env:extmirrbase\emcmd.exe" sios-0 getserviceinfo 2>"C:\Windows\Temp\datakeeperWMI10Error.txt"
				$results | Out-File -FilePath $logfile -Encoding "UTF8" -Force
				
				$logfile = "C:\Windows\Temp\datakeeperWMI11.txt"
				$results = & "$env:extmirrbase\emcmd.exe" sios-1 getserviceinfo 2>"C:\Windows\Temp\datakeeperWMI11Error.txt"
				$results | Out-File -FilePath $logfile -Encoding "UTF8" -Force
				
				$logfile = "C:\Windows\Temp\datakeeperWMI12.txt"
				$results = & "$env:extmirrbase\emcmd.exe" 10.0.0.5 getserviceinfo 2>"C:\Windows\Temp\datakeeperWMI12Error.txt"
				$results | Out-File -FilePath $logfile -Encoding "UTF8" -Force
				
				$logfile = "C:\Windows\Temp\datakeeperWMI13.txt"
				$results = & "$env:extmirrbase\emcmd.exe" 10.0.0.6 getserviceinfo 2>"C:\Windows\Temp\datakeeperWMI13Error.txt"
				$results | Out-File -FilePath $logfile -Encoding "UTF8" -Force
				
				$logfile = "C:\Windows\Temp\datakeeperWMI14.txt"
			}
			TestScript = { $false }
			GetScript = {@{}}
			Credential = $Admincreds
			DependsOn = "[sService]StartExtMirr"
		}
		
        LocalConfigurationManager 
        {
            RebootNodeIfNeeded = $true
        }

    }
}

function Get-NetBIOSName
{ 
    [OutputType([string])]
    param(
        [string]$DomainName
    )

    if ($DomainName.Contains('.')) {
        $length=$DomainName.IndexOf('.')
        if ( $length -ge 16) {
            $length=15
        }
        return $DomainName.Substring(0,$length)
    }
    else {
        if ($DomainName.Length -gt 15) {
            return $DomainName.Substring(0,15)
        }
        else {
            return $DomainName
        }
    }
}

function Enable-CredSSPNTLM
{ 
    param(
        [Parameter(Mandatory=$true)]
        [string]$DomainName
    )
    
    # This is needed for the case where NTLM authentication is used

    Write-Verbose 'STARTED:Setting up CredSSP for NTLM'
   
    Enable-WSManCredSSP -Role client -DelegateComputer localhost, *.$DomainName -Force -ErrorAction SilentlyContinue
    Enable-WSManCredSSP -Role server -Force -ErrorAction SilentlyContinue

    if(-not (Test-Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -ErrorAction SilentlyContinue))
    {
        New-Item -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows -Name '\CredentialsDelegation' -ErrorAction SilentlyContinue
    }

    if( -not (Get-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -Name 'AllowFreshCredentialsWhenNTLMOnly' -ErrorAction SilentlyContinue))
    {
        New-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -Name 'AllowFreshCredentialsWhenNTLMOnly' -value '1' -PropertyType dword -ErrorAction SilentlyContinue
    }

    if (-not (Get-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -Name 'ConcatenateDefaults_AllowFreshNTLMOnly' -ErrorAction SilentlyContinue))
    {
        New-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -Name 'ConcatenateDefaults_AllowFreshNTLMOnly' -value '1' -PropertyType dword -ErrorAction SilentlyContinue
    }

    if(-not (Test-Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -ErrorAction SilentlyContinue))
    {
        New-Item -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -Name 'AllowFreshCredentialsWhenNTLMOnly' -ErrorAction SilentlyContinue
    }

    if (-not (Get-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name '1' -ErrorAction SilentlyContinue))
    {
        New-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name '1' -value "wsman/$env:COMPUTERNAME" -PropertyType string -ErrorAction SilentlyContinue
    }

    if (-not (Get-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name '2' -ErrorAction SilentlyContinue))
    {
        New-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name '2' -value "wsman/localhost" -PropertyType string -ErrorAction SilentlyContinue
    }

    if (-not (Get-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name '3' -ErrorAction SilentlyContinue))
    {
        New-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name '3' -value "wsman/*.$DomainName" -PropertyType string -ErrorAction SilentlyContinue
    }

    Write-Verbose "DONE:Setting up CredSSP for NTLM"
}
