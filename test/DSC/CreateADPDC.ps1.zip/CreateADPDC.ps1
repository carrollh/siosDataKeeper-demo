﻿configuration CreateADPDC 
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Parameter(Mandatory)]
        [String]$SharePath,

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    ) 
    
    Import-DscResource -ModuleName cDisk, xActiveDirectory, xDisk, xNetworking, xSMBShare, PSDesiredStateConfiguration
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    $Interface=Get-NetAdapter|Where Name -Like "Ethernet*"|Select-Object -First 1
    $InterfaceAlias=$($Interface.Name)

    Node localhost
    {
		WindowsFeature DNS 
		{ 
			Ensure = "Present" 
			Name = "DNS"		
		}
		
		WindowsFeature DnsTools
		{
			Ensure = "Present"
				Name = "RSAT-DNS-Server"
		}

		xDnsServerAddress DnsServerAddress 
		{ 
			Address        = '127.0.0.1' 
			InterfaceAlias = $InterfaceAlias
			AddressFamily  = 'IPv4'
			DependsOn = "[WindowsFeature]DNS"
		}
		
		WindowsFeature ADDSInstall 
		{ 
			Ensure = "Present" 
			Name = "AD-Domain-Services"
			DependsOn="[xDnsServerAddress]DnsServerAddress "
		}  

		File FSWFolder
		{
			DestinationPath = "C:\$($SharePath.ToUpperInvariant())"
			Type = "Directory"
			Ensure = "Present"
			DependsOn = "[WindowsFeature]ADDSInstall"
		}

		xSmbShare FSWShare
		{
			Name = $SharePath.ToUpperInvariant()
			Path = "C:\$($SharePath.ToUpperInvariant())"
			FullAccess = "BUILTIN\Administrators"
			Ensure = "Present"
			DependsOn = "[File]FSWFolder"
		}
		
		Script Script2 {
				
			SetScript =  { 
				Set-DnsServerDiagnostics -All $true

				$logfile = "C:\Windows\Temp\datakeeperAddComputers"
				"Waiting on Computers to exist on the domain..." > $logfile
				
				$DomainNetbiosName=Get-NetBIOSName -DomainName $DomainName -ErrorAction SilentlyContinue
				while( $DomainNetbiosName -eq $NULL) {
					$DomainNetbiosName = Get-NetBIOSName -DomainName $DomainName -ErrorAction SilentlyContinue
				}
				
				while( $(Get-ADComputer "sios-0" -ErrorAction SilentlyContinue) -eq $NULL ) {
					Start-Sleep 10
				}
				
				$results = dsmod group "cn=domain admins,cn=users,dc=$DomainNetbiosName,dc=local" -addmbr "CN=sios-0,CN=Computers,DC=$DomainNetbiosName,DC=local" 2>"C:\Windows\datakeeperSios0FAILURE.txt"
				$results >> $logfile
				
				while( $(Get-ADComputer "sios-1" -ErrorAction SilentlyContinue) -eq $NULL ) {
					Start-Sleep 10
				}
				
				$results = dsmod group "cn=domain admins,cn=users,dc=$DomainNetbiosName,dc=local" -addmbr "CN=sios-1,CN=Computers,DC=$DomainNetbiosName,DC=local" 2>"C:\Windows\datakeeperSios1FAILURE.txt"
				$results >> $logfile
			}
			GetScript =  { @{} }
			TestScript = { $false}
			DependsOn = "[WindowsFeature]ADDSInstall"	 
		}

		LocalConfigurationManager 
		{
			ConfigurationMode = 'ApplyOnly'
			RebootNodeIfNeeded = $true
		}
	}
} 