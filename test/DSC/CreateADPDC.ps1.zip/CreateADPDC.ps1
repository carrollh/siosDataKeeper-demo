﻿configuration CreateADPDC 
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Parameter(Mandatory)]
        [String]$SharePath,

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    ) 
    
    Import-DscResource -ModuleName cDisk, xActiveDirectory, xDisk, xNetworking, xSMBShare, PSDesiredStateConfiguration
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    $Interface=Get-NetAdapter|Where Name -Like "Ethernet*"|Select-Object -First 1
    $InterfaceAlias=$($Interface.Name)

    Node localhost
    {
		Script script1
		{
			SetScript =  { 
				Set-DnsServerDiagnostics -All $true
				Write-Verbose -Verbose "Enabling DNS client diagnostics"

				$logfile = "C:\Windows\Temp\datakeeperAddComputers"
				"Adding computers to the domain admins group">$logfile

				try {
					Set-NetFirewallProfile -Profile Domain,Public,Private -Enabled False
					
					$secpasswd = ConvertTo-SecureString "SIOS!5105" -AsPlainText -Force
					$mycreds = New-Object System.Management.Automation.PSCredential ("datakeeper\siosadmin", $secpasswd)
					
					$sios0 = New-ADComputer -AccountExpirationDate $NULL -DNSHostName ("SIOS-0." + $(Get-ADDomain).DNSRoot) -PasswordNotRequired $true -TrustedForDelegation $true -Confirm:$false -Name "SIOS-0" 2>>$logfile
					$results = Add-AdGroupMember -Identity "Domain Admins" -Member $sios0 -Credential $mycreds -Confirm:$false 2>>$logfile
					$results>>$logfile
				} catch [Exception] {
					echo $_.Exception|format-list -force >>$logfile
					"It didn't work, did the reason get logged before this line?">>$logfile
				}
				
			}
			GetScript =  { @{} }
			TestScript = { $false}
			DependsOn = "[xADDomain]FirstDS"
        }
	
		WindowsFeature DNS 
		{ 
			Ensure = "Present" 
			Name = "DNS"		
		}

		WindowsFeature DnsTools
		{
			Ensure = "Present"
				Name = "RSAT-DNS-Server"
		}

		xDnsServerAddress DnsServerAddress 
		{ 
			Address        = '127.0.0.1' 
			InterfaceAlias = $InterfaceAlias
			AddressFamily  = 'IPv4'
			DependsOn = "[WindowsFeature]DNS"
		}

		xWaitforDisk Disk2
		{
				DiskNumber = 2
				RetryIntervalSec =$RetryIntervalSec
				RetryCount = $RetryCount
		}
		
		cDiskNoRestart ADDataDisk
		{
			DiskNumber = 2
			DriveLetter = "F"
		}
		
		WindowsFeature ADDSInstall 
		{ 
			Ensure = "Present" 
			Name = "AD-Domain-Services"
			DependsOn="[cDiskNoRestart]ADDataDisk"
		}  

		xADDomain FirstDS 
		{
			DomainName = $DomainName
			DomainAdministratorCredential = $DomainCreds
			SafemodeAdministratorPassword = $DomainCreds
			DatabasePath = "F:\NTDS"
			LogPath = "F:\NTDS"
			SysvolPath = "F:\SYSVOL"
			DependsOn = "[WindowsFeature]ADDSInstall"
		} 

		File FSWFolder
		{
			DestinationPath = "F:\$($SharePath.ToUpperInvariant())"
			Type = "Directory"
			Ensure = "Present"
			DependsOn = "[xADDomain]FirstDS"
		}

		xSmbShare FSWShare
		{
			Name = $SharePath.ToUpperInvariant()
			Path = "F:\$($SharePath.ToUpperInvariant())"
			FullAccess = "BUILTIN\Administrators"
			Ensure = "Present"
			DependsOn = "[File]FSWFolder"
		}

		LocalConfigurationManager 
		{
			ConfigurationMode = 'ApplyOnly'
			RebootNodeIfNeeded = $true
		}
	}
} 