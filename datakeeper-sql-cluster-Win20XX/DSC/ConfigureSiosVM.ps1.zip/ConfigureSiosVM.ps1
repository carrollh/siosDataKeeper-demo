configuration ConfigureSiosVM
{
    param
    (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$AdminCreds,

        [String]$DomainNetbiosName=(Get-NetBIOSName -DomainName $DomainName),

	[Parameter(Mandatory)]
        [String]$LicenseKeyFtpURL,

        [Int]$RetryCount=40,
				
        [Int]$RetryIntervalSec=30
    )

    Import-DscResource -ModuleName cDisk, xActiveDirectory, xComputerManagement, xDataKeeper, xDisk, xNetworking
    
    $domainFQDN = Add-TopLevelDomain $DomainName
    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainNetbiosName}\$($AdminCreds.UserName)", $AdminCreds.Password)
	
    Node localhost
    {
        xWaitforDisk Disk2
        {
            DiskNumber = 2
            RetryIntervalSec =$RetryIntervalSec
            RetryCount = $RetryCount
        }

        cDiskNoRestart DataDisk
        {
            DiskNumber = 2
            DriveLetter = "F"
        }

        WindowsFeature NET35
        {
            Name = "WAS-NET-Environment"
            Ensure = "Present"
        }
        
        WindowsFeature FC
        {
            Name = "Failover-Clustering"
            Ensure = "Present"
        }

        WindowsFeature FCMGMT
        {
            Name = "RSAT-Clustering-Mgmt"
            Ensure = "Present"
        }

        WindowsFeature FCPS
        {
            Name = "RSAT-Clustering-PowerShell"
            Ensure = "Present"
        }

        WindowsFeature ADPS
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        }
				
        xWaitForADDomain DscForestWait 
        { 
            DomainName = $domainFQDN 
            DomainUserCredential= $DomainCreds
            RetryCount = $RetryCount 
            RetryIntervalSec = $RetryIntervalSec 
            DependsOn = "[WindowsFeature]ADPS"
        }
				
        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $domainFQDN
            Credential = $DomainCreds
			DependsOn = "[xWaitForADDomain]DscForestWait"
        }

		DownloadDKCE GetDKCE
		{
			DataKeeperFTPURL = "http://e512b7db7365eaa2f93b-44b251abad247bc1e9143294cbaa102a.r50.cf5.rackcdn.com/windows/SIOS_DataKeeper_Windows_en_8.4.0/DataKeeperv8.4.0-1995/DK-8.4.0-Setup.exe"
			DownloadPath = "$env:windir\Temp\"
			RetryCount = $RetryCount 
			RetryIntervalSec = $RetryIntervalSec 
			DependsOn = "[xComputer]DomainJoin"
		}
		
		InstallDKCE InstallDataKeeper
		{
			InstallerPath = "$env:windir\Temp\DK-8.4.0-Setup.exe"
			SetupFilePath = "$env:windir\Temp\setup.iss"
			AdminCredential = $DomainCreds
			DependsOn = "[DownloadDKCE]GetDKCE"
			PsDscRunAsCredential = $DomainCreds
		}
        
		InstallLicense GetDKCELic
		{
			LicenseKeyFtpURL = $LicenseKeyFtpURL 
			RetryIntervalSec = $RetryIntervalSec
			RetryCount = $RetryCount 
			DependsOn = "[InstallDKCE]InstallDataKeeper"
		}

		sService StartExtMirr
		{
			Name = "extmirrsvc"
			StartupType = "Automatic"
			State = "Running"
			DependsOn = "[InstallLicense]GetDKCELic"
		}
		
		DownloadSQLServer GetSQL
		{
			SQLServerURL = "http://care.dlservice.microsoft.com/dl/download/2/F/8/2F8F7165-BB21-4D1E-B5D8-3BD3CE73C77D/SQLServer2014SP1-FullSlipstream-x64-ENU.iso"
			ISODownloadPath = "$env:windir\Temp\"
			FinalPathToFiles = "C:\SQL2014\"
			DependsOn = "[sService]StartExtMirr"
			PsDscRunAsCredential = $DomainCreds
		}
<#		
		AddClusteredSQLNode InstallSQL
		{
			AdminCredential = $AdminCreds
			DomainNetbiosName = $DomainNetbiosName
			DependsOn = "[DownloadSQLServer]GetSQL"
			PsDscRunAsCredential = $DomainCreds
		}
#>	
        LocalConfigurationManager 
        {
            RebootNodeIfNeeded = $true
        }

    }
}

function Get-NetBIOSName
{ 
    [OutputType([string])]
    param(
        [string]$DomainName
    )

    if ($DomainName.Contains('.')) {
        $length=$DomainName.IndexOf('.')
        if ( $length -ge 16) {
            $length=15
        }
        return $DomainName.Substring(0,$length)
    }
    else {
        if ($DomainName.Length -gt 15) {
            return $DomainName.Substring(0,15)
        }
        else {
            return $DomainName
        }
    }
}

function Add-TopLevelDomain
{ 
    [OutputType([string])]
    param(
        [string]$DomainName
    )

    if ($DomainName.Contains('.')) {
        return $DomainName
    }
    else {
        return ($DomainName + ".local")
    }
}